import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Building2, 
  TrendingUp, 
  Award, 
  Users, 
  Trophy, 
  RefreshCw, 
  User, 
  Edit3, 
  Check, 
  DollarSign, 
  Map, 
  Coins, 
  ChevronRight, 
  ShieldCheck, 
  PiggyBank 
} from 'lucide-react';

import { GameState, Business, Investment, Achievement, Rival, Club } from './types';
import AtmCard from './components/AtmCard';
import BusinessTab from './components/BusinessTab';
import InvestmentTab from './components/InvestmentTab';
import ClubTab from './components/ClubTab';
import AchievementsTab from './components/AchievementsTab';
import RankTab from './components/RankTab';

// Initial Game Setup values
const INITIAL_STATE: GameState = {
  cash: 200,
  totalEarned: 0,
  multiplier: 1.0,
  lastTick: Date.now(),
  club: { active: false, name: '', lvl: 1, exp: 0, req: 500 },
  biz: [
    { id: 0, n: "Kedai Kopi", lvl: 1, cost: 20, inc: 8, dur: 1500, mgr: false, mc: 800, prog: 0, run: false },
    { id: 1, n: "Bengkel", lvl: 0, cost: 400, inc: 75, dur: 4000, mgr: false, mc: 4500, prog: 0, run: false },
    { id: 2, n: "Pabrik Garmen", lvl: 0, cost: 6000, inc: 900, dur: 12000, mgr: false, mc: 50000, prog: 0, run: false }
  ],
  inv: [
    { id: 0, n: "Bitcoin", p: 65000, basePrice: 65000, history: [65000, 67200, 63800, 65000], o: 0, type: 'crypto' },
    { id: 1, n: "Saham NVDA", p: 120, basePrice: 120, history: [120, 118, 122, 120], o: 0, type: 'stock' },
    { id: 2, n: "Apartemen", p: 150000, basePrice: 150000, rent: 1500, history: [150000], o: 0, type: 'prop' }
  ],
  ach: [
    { id: 0, n: "Pebisnis Pemula", d: "Rencanakan & hasilkan omset kumulatif pertama senilai $5,000", goal: 5000, type: 'earnings', done: false },
    { id: 1, n: "Juragan Properti", d: "Miliki minimal 1 unit Apartemen sewa pasif luar biasa", goal: 1, type: 'prop', done: false },
    { id: 2, n: "Status Elit", d: "Bangun dinasti kekaisaran dengan hasil omset senilai $1,000,000", goal: 1000000, type: 'prestige', done: false }
  ],
  rivals: [
    { n: "Budi Rich", w: 25000 },
    { n: "Sultan Andara", w: 5000000 },
    { n: "Elon Emas", w: 990000000 }
  ]
};

export default function App() {
  const [gameState, setGameState] = useState<GameState>(INITIAL_STATE);
  const [activeTab, setActiveTab] = useState<'biz' | 'inv' | 'club' | 'ach' | 'rank'>('biz');
  const [playerName, setPlayerName] = useState("Direktur Utama");
  const [isEditingName, setIsEditingName] = useState(false);
  const [nameInput, setNameInput] = useState(playerName);
  const [toasts, setToasts] = useState<{ id: number; text: string }[]>([]);

  // Function to drop a notification toast
  const triggerToast = (text: string) => {
    const id = Date.now() + Math.random();
    setToasts(prev => [...prev, { id, text }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4000);
  };

  // On mount: load game state & player name from localStorage
  useEffect(() => {
    const savedState = localStorage.getItem("syarikat_elit_gamestate");
    const savedName = localStorage.getItem("syarikat_elit_playername");
    
    if (savedName) {
      setPlayerName(savedName);
      setNameInput(savedName);
    }
    
    if (savedState) {
      try {
        const parsed = JSON.parse(savedState);
        // Correct time reference to modern timestamp to prevent overnight overflow cascades
        parsed.lastTick = Date.now();
        
        // Ensure older state updates inherit newer data structures (like trend history)
        parsed.inv = parsed.inv.map((item: any, idx: number) => {
          const fallback = INITIAL_STATE.inv[idx];
          return {
            ...fallback,
            ...item,
            history: item.history || fallback.history
          };
        });

        setGameState(parsed);
      } catch (err) {
        console.error("Failed to restore previous save-file:", err);
      }
    }
  }, []);

  // Save game state automatically on updates
  useEffect(() => {
    if (gameState.totalEarned > 0 || gameState.cash !== 200) {
      localStorage.setItem("syarikat_elit_gamestate", JSON.stringify(gameState));
    }
  }, [gameState]);

  // Main high-frequency timer loop (Ticking business progression & passive rent)
  useEffect(() => {
    const mainTimer = setInterval(() => {
      setGameState(prev => {
        const now = Date.now();
        const dt = now - prev.lastTick;

        // Calculate continuous real estate apartment rent
        const rentalYield = prev.inv
          .filter(i => i.type === 'prop')
          .reduce((sum, item) => sum + ((item.rent || 0) * item.o), 0);
        
        const passiveGained = rentalYield * (dt / 1000);
        let newCash = prev.cash + passiveGained;
        let newTotalEarned = prev.totalEarned + passiveGained;

        // Compute active/processed business levels progress bars
        let earnedFromBiz = 0;
        const updatedBiz = prev.biz.map(b => {
          let item = { ...b };
          if (item.lvl > 0) {
            // Auto start if manager hired
            if (item.mgr && !item.run) {
              item.run = true;
            }

            if (item.run) {
              item.prog += (dt / item.dur) * 100;
              if (item.prog >= 100) {
                item.prog = 0;
                item.run = item.mgr; // Stay running if managed, else reset click
                const payout = item.inc * item.lvl * prev.multiplier;
                earnedFromBiz += payout;
              }
            }
          }
          return item;
        });

        newCash += earnedFromBiz;
        newTotalEarned += earnedFromBiz;

        // Verification & unlock criteria for Achievements
        const updatedAch = prev.ach.map(a => {
          if (a.done) return a;
          let done = false;
          
          if (a.id === 0 && newTotalEarned >= a.goal) done = true;
          else if (a.id === 1) {
            const currentApartments = prev.inv.find(i => i.id === 2)?.o || 0;
            if (currentApartments >= a.goal) done = true;
          }
          else if (a.id === 2 && newTotalEarned >= a.goal) done = true;

          if (done) {
            // Trigger deferred notification safely outside core loop
            setTimeout(() => {
              triggerToast(`🏆 Achievement Terbuka:<br/><b>${a.n}</b> - ${a.d}`);
            }, 50);
          }
          return { ...a, done };
        });

        return {
          ...prev,
          cash: newCash,
          totalEarned: newTotalEarned,
          biz: updatedBiz,
          ach: updatedAch,
          lastTick: now
        };
      });
    }, 100);

    return () => clearInterval(mainTimer);
  }, []);

  // Financial Market variation timer loop (Stocks / Cryptocurrencies volatility updates)
  useEffect(() => {
    const marketTimer = setInterval(() => {
      setGameState(prev => {
        const updatedInv = prev.inv.map(item => {
          if (item.type === 'prop') return item; // Properties index stays flat
          
          // Random walk volatility: -9% to +11%
          const changeRatio = (0.91 + Math.random() * 0.20);
          const nextPrice = Math.max(1, Math.round(item.p * changeRatio));
          
          // Chart points storage
          const nextHistory = [...(item.history || [item.p])];
          nextHistory.push(nextPrice);
          if (nextHistory.length > 15) {
            nextHistory.shift();
          }

          return {
            ...item,
            p: nextPrice,
            history: nextHistory
          };
        });

        // Slowly index rivals holdings by 0.2% - 1.4%
        const updatedRivals = prev.rivals.map(rival => {
          return {
            ...rival,
            w: rival.w * (1.002 + Math.random() * 0.012)
          };
        });

        return {
          ...prev,
          inv: updatedInv,
          rivals: updatedRivals
        };
      });
    }, 3000);

    return () => clearInterval(marketTimer);
  }, []);

  // Business Action handlers
  const handleUpgradeBiz = (id: number) => {
    setGameState(prev => {
      const b = prev.biz[id];
      const cost = b.cost * Math.pow(1.15, b.lvl);
      if (prev.cash >= cost) {
        const updatedBiz = [...prev.biz];
        updatedBiz[id] = { ...b, lvl: b.lvl + 1 };
        return {
          ...prev,
          cash: prev.cash - cost,
          biz: updatedBiz
        };
      }
      return prev;
    });
  };

  const handleHireManager = (id: number) => {
    setGameState(prev => {
      const b = prev.biz[id];
      if (prev.cash >= b.mc && b.lvl > 0 && !b.mgr) {
        const updatedBiz = [...prev.biz];
        updatedBiz[id] = { ...b, mgr: true, run: true };
        
        setTimeout(() => {
          triggerToast(`💼 Manager <b>${b.n}</b> diaktifkan!<br/>Operasional otomatis berjalan.`);
        }, 50);

        return {
          ...prev,
          cash: prev.cash - b.mc,
          biz: updatedBiz
        };
      }
      return prev;
    });
  };

  const handleManualTrigger = (id: number) => {
    setGameState(prev => {
      const b = prev.biz[id];
      if (b.lvl > 0 && !b.run) {
        const updatedBiz = [...prev.biz];
        updatedBiz[id] = { ...b, run: true, prog: 0 };
        return {
          ...prev,
          biz: updatedBiz
        };
      }
      return prev;
    });
  };

  // Investment Trading handlers
  const handleTradeAsset = (id: number, buy: boolean) => {
    setGameState(prev => {
      const item = prev.inv[id];
      if (buy && prev.cash >= item.p) {
        const updatedInv = [...prev.inv];
        updatedInv[id] = { ...item, o: item.o + 1 };
        return {
          ...prev,
          cash: prev.cash - item.p,
          inv: updatedInv
        };
      } else if (!buy && item.o > 0 && item.type !== 'prop') {
        const updatedInv = [...prev.inv];
        updatedInv[id] = { ...item, o: item.o - 1 };
        return {
          ...prev,
          cash: prev.cash + item.p,
          inv: updatedInv
        };
      }
      return prev;
    });
  };

  // Club Charter & Funding handles
  const handleCreateClub = (clubName: string) => {
    setGameState(prev => {
      if (prev.cash >= 10000 && !prev.club.active) {
        setTimeout(() => {
          triggerToast(`🏛️ Klub Elite <b>${clubName}</b> telah didirikan!<br/>Multiplier bonus kini aktif.`);
        }, 50);

        return {
          ...prev,
          cash: prev.cash - 10000,
          club: {
            active: true,
            name: clubName,
            lvl: 1,
            exp: 0,
            req: 500
          }
        };
      }
      return prev;
    });
  };

  const handleDonateClub = (cost: number, xpGained: number) => {
    setGameState(prev => {
      if (prev.cash >= cost && prev.club.active) {
        let newXp = prev.club.exp + xpGained;
        let newLvl = prev.club.lvl;
        let newReq = prev.club.req;

        while (newXp >= newReq) {
          newXp -= newReq;
          newLvl += 1;
          newReq = Math.round(newReq * 1.5);
          
          // Call out to notify levels asynchronously
          const capturedLevel = newLvl;
          setTimeout(() => {
            triggerToast(`🏛️ <b>Klub Naik Level!</b><br/>Level ${capturedLevel} meningkatkan keuntungan x${(1.0 + (capturedLevel - 1) * 0.15).toFixed(2)}!`);
          }, 50);
        }

        return {
          ...prev,
          cash: prev.cash - cost,
          multiplier: 1.0 + (newLvl - 1) * 0.15,
          club: {
            ...prev.club,
            lvl: newLvl,
            exp: newXp,
            req: newReq
          }
        };
      }
      return prev;
    });
  };

  // Player Name save hook
  const handleSavePlayerName = () => {
    if (nameInput.trim()) {
      setPlayerName(nameInput.trim());
      localStorage.setItem("syarikat_elit_playername", nameInput.trim());
      setIsEditingName(false);
      triggerToast("Profil nama berhasil diperbarui!");
    }
  };

  // Master reset game progression
  const handleResetGame = () => {
    if (window.confirm("Apakah Anda yakin ingin menyetel ulang data permainan? Seluruh keuntungan, bisnis, dan pencapaian akan dihapus.")) {
      localStorage.removeItem("syarikat_elit_gamestate");
      localStorage.removeItem("syarikat_elit_playername");
      setGameState(INITIAL_STATE);
      setPlayerName("Direktur Utama");
      setNameInput("Direktur Utama");
      setActiveTab('biz');
      triggerToast("Data permainan berhasil disetel ulang!");
    }
  };

  // Calculations for general statistics bar
  const formatValue = (n: number) => {
    return n.toLocaleString('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 });
  };

  const totalPassiveRent = gameState.inv
    .filter(i => i.type === 'prop')
    .reduce((sum, item) => sum + ((item.rent || 0) * item.o), 0);

  const totalNetWorth = gameState.cash + gameState.inv.reduce((sum, item) => sum + (item.p * item.o), 0);

  return (
    <div className="min-h-screen pb-16 font-sans bg-brand-bg text-[#ffffff] select-none">
      {/* Absolute floating toast panel */}
      <div className="fixed top-4 right-4 z-50 space-y-2 pointer-events-none max-w-sm w-full">
        <AnimatePresence>
          {toasts.map((t) => (
            <motion.div
              key={t.id}
              initial={{ x: 100, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: 150, opacity: 0 }}
              transition={{ type: 'spring', stiffness: 220, damping: 20 }}
              className="pointer-events-auto bg-[#141414] border-l-4 border-l-brand-gold text-slate-100 p-4 rounded-lg shadow-2xl border border-white/5 flex items-start gap-2.5"
            >
              <div className="w-5 h-5 mt-0.5 rounded-full bg-brand-gold/10 flex items-center justify-center shrink-0">
                <Trophy className="w-3 h-3 text-brand-gold" />
              </div>
              <div className="text-xs space-y-0.5">
                <div dangerouslySetInnerHTML={{ __html: t.text }} className="leading-relaxed text-zinc-300 font-sans" />
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Corporate Executive Navbar Header */}
      <header className="border-b border-white/10 bg-black/60 backdrop-blur-md sticky top-0 z-30 px-4 py-3.5 shadow-sm">
        <div className="max-w-4xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-start">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded bg-[#111] border border-brand-gold/30 flex items-center justify-center shadow">
                <Building2 className="w-4 h-4 text-brand-gold stroke-[2]" />
              </div>
              <div>
                <h1 className="font-serif italic font-semibold text-lg tracking-wide text-white leading-tight">
                  Syarikat Elit
                </h1>
                <span className="text-[8px] uppercase tracking-[0.25em] text-brand-gold block font-bold">
                  Ultimate Fix Edition
                </span>
              </div>
            </div>

            {/* Profile editor button */}
            <div className="flex items-center gap-1.5 text-zinc-400 bg-black border border-white/10 rounded-lg px-2.5 py-1 text-xs">
              <User className="w-3.5 h-3.5 text-zinc-550" />
              {isEditingName ? (
                <div className="flex items-center gap-1.5" id="name-form">
                  <input
                    type="text"
                    maxLength={16}
                    value={nameInput}
                    onChange={(e) => setNameInput(e.target.value)}
                    className="bg-transparent border-0 font-sans outline-none focus:ring-0 text-slate-100 p-0 text-xs w-20 sm:w-24 border-b border-brand-gold"
                    autoFocus
                  />
                  <button type="button" onClick={handleSavePlayerName} className="text-emerald-400 hover:text-emerald-300">
                    <Check className="w-3.5 h-3.5" />
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-1">
                  <span className="font-medium text-slate-200">{playerName}</span>
                  <button type="button" onClick={() => setIsEditingName(true)} className="text-zinc-650 hover:text-brand-gold cursor-pointer transition-colors">
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center gap-5 w-full sm:w-auto justify-around sm:justify-end font-mono text-center sm:text-right">
            <div>
              <span className="text-[9px] uppercase tracking-widest text-zinc-500 block">Kekayaan Bersih</span>
              <span className="text-sm font-semibold text-white block">
                {formatValue(totalNetWorth)}
              </span>
            </div>
            <div className="h-6 w-[1px] bg-white/10" />
            <div>
              <span className="text-[9px] uppercase tracking-widest text-[#888888] block">Usaha Pasif</span>
              <span className="text-sm font-semibold text-brand-gold block">
                {formatValue(totalPassiveRent)}/s
              </span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Display Container */}
      <main className="max-w-4xl mx-auto px-4 mt-6 grid grid-cols-1 md:grid-cols-12 gap-6">
        
        {/* Left Side: ATM Card Display and Global Score Balance */}
        <section className="md:col-span-5 space-y-6">
          <div className="custom-card rounded-2xl p-6 bg-[#111111] border border-white/10 flex flex-col justify-between items-center text-center relative overflow-hidden shadow-xl">
            {/* Ambient Background decoration */}
            <div className="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-brand-gold via-yellow-300 to-brand-gold" />
            
            <div className="space-y-1 mb-5 relative z-10 w-full text-center">
              <span className="text-[10px] uppercase tracking-widest text-brand-gold font-bold flex items-center justify-center gap-1.5">
                <PiggyBank className="w-4 h-4" />
                Sisa Saldo Kas Utama
              </span>
              <div className="font-mono text-3xl sm:text-4xl font-semibold text-[#ffffff] drop-shadow-md tracking-tight select-all mt-1">
                {formatValue(gameState.cash)}
              </div>
            </div>

            <div className="w-full relative z-10">
              <AtmCard 
                totalEarned={gameState.totalEarned} 
                playerName={playerName} 
              />
            </div>
          </div>

          {/* Quick instructions manual */}
          <div className="custom-card rounded-xl p-4 bg-[#111111]/80 text-xs text-[#888888] space-y-2 border border-white/5">
            <h4 className="font-serif italic font-medium text-slate-100 flex items-center gap-1">
              SOP Syarikat Elit:
            </h4>
            <ol className="list-decimal pl-4 space-y-1 leading-relaxed font-sans text-[11px]">
              <li>Mulai dengan memicu usaha <b className="text-zinc-300">Kedai Kopi</b> secara manual.</li>
              <li>Akumulasikan dana untuk meningkatkan Level usaha guna melipatgandakan penghasilan.</li>
              <li>Pekerjakan <b className="text-zinc-300 font-semibold">Manager</b> agar roda bisnis berputar otomatis.</li>
              <li>Tanam modal di bursa saham (<b className="text-zinc-300">NVDA</b>) atau uang kripto (<b className="text-zinc-300 font-semibold">Bitcoin</b>) untuk melipatgandakan keuntungan.</li>
              <li>Beli <b className="text-zinc-300">Apartemen</b> untuk hasil sewa pasif tanpa batas.</li>
              <li>Bentuk <b className="text-zinc-300 font-semibold">Klub</b> guna memicu profit multiplier global permanen.</li>
            </ol>
          </div>
        </section>

        {/* Right Side: Navigation Tabs and Core Modules */}
        <section className="md:col-span-7 space-y-4">
          
          {/* Tabs Menu Navigation Bar (Sleek minimalist style) */}
          <div className="flex items-center gap-1.5 p-1 bg-black/50 border border-white/10 rounded-xl overflow-x-auto">
            {/* Tab Bisnis */}
            <button
              type="button"
              onClick={() => setActiveTab('biz')}
              className={`flex items-center gap-1 px-3 py-2 text-xs sm:text-xs font-semibold rounded-lg shrink-0 transition-colors uppercase tracking-widest border border-transparent ${
                activeTab === 'biz'
                  ? 'bg-white text-black font-bold shadow-md'
                  : 'text-zinc-400 hover:bg-white/5 hover:text-white'
              }`}
            >
              <Building2 className="w-3.5 h-3.5" />
              Bisnis
            </button>

            {/* Tab Investasi */}
            <button
              type="button"
              onClick={() => setActiveTab('inv')}
              className={`flex items-center gap-1 px-3 py-2 text-xs sm:text-xs font-semibold rounded-lg shrink-0 transition-colors uppercase tracking-widest border border-transparent ${
                activeTab === 'inv'
                  ? 'bg-white text-black font-bold shadow-md'
                  : 'text-zinc-400 hover:bg-white/5 hover:text-white'
              }`}
            >
              <TrendingUp className="w-3.5 h-3.5" />
              Investasi
            </button>

            {/* Tab Klub */}
            <button
              type="button"
              onClick={() => setActiveTab('club')}
              className={`flex items-center gap-1 px-3 py-2 text-xs sm:text-xs font-semibold rounded-lg shrink-0 transition-colors uppercase tracking-widest border border-transparent ${
                activeTab === 'club'
                  ? 'bg-white text-black font-bold shadow-md'
                  : 'text-zinc-400 hover:bg-white/5 hover:text-white'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              Klub
            </button>

            {/* Tab Achievement */}
            <button
              type="button"
              onClick={() => setActiveTab('ach')}
              className={`flex items-center gap-1 px-3 py-2 text-xs sm:text-xs font-semibold rounded-lg shrink-0 transition-colors uppercase tracking-widest border border-transparent ${
                activeTab === 'ach'
                  ? 'bg-white text-black font-bold shadow-md'
                  : 'text-zinc-400 hover:bg-white/5 hover:text-white'
              }`}
            >
              <Trophy className="w-3.5 h-3.5" />
              Trophy
            </button>

            {/* Tab Papan Peringkat */}
            <button
              type="button"
              onClick={() => setActiveTab('rank')}
              className={`flex items-center gap-1 px-3 py-2 text-xs sm:text-xs font-semibold rounded-lg shrink-0 transition-colors uppercase tracking-widest border border-transparent ${
                activeTab === 'rank'
                  ? 'bg-white text-black font-bold shadow-md'
                  : 'text-zinc-400 hover:bg-white/5 hover:text-white'
              }`}
            >
              <Award className="w-3.5 h-3.5" />
              Rival
            </button>
          </div>

          {/* Active Panel Outlet */}
          <div className="bg-transparent mt-2">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.15 }}
              >
                {activeTab === 'biz' && (
                  <BusinessTab
                    biz={gameState.biz}
                    cash={gameState.cash}
                    multiplier={gameState.multiplier}
                    onUpgrade={handleUpgradeBiz}
                    onHireManager={handleHireManager}
                    onManualTrigger={handleManualTrigger}
                  />
                )}

                {activeTab === 'inv' && (
                  <InvestmentTab
                    inv={gameState.inv}
                    cash={gameState.cash}
                    onTrade={handleTradeAsset}
                  />
                )}

                {activeTab === 'club' && (
                  <ClubTab
                    club={gameState.club}
                    cash={gameState.cash}
                    onCreateClub={handleCreateClub}
                    onDonateClub={handleDonateClub}
                  />
                )}

                {activeTab === 'ach' && (
                  <AchievementsTab
                    ach={gameState.ach}
                    totalEarned={gameState.totalEarned}
                    inv={gameState.inv}
                  />
                )}

                {activeTab === 'rank' && (
                  <RankTab
                    rivals={gameState.rivals}
                    cash={gameState.cash}
                    inv={gameState.inv}
                    playerName={playerName}
                  />
                )}
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Utilities panel */}
          <div className="flex justify-end pt-2">
            <button
              type="button"
              onClick={handleResetGame}
              className="text-xs text-zinc-650 hover:text-rose-500 transition-colors flex items-center gap-1 font-mono hover:underline cursor-pointer"
            >
              <RefreshCw className="w-3 h-3" />
              Seter Ulang Data Syarikat (Restart)
            </button>
          </div>

        </section>
      </main>
    </div>
  );
}
