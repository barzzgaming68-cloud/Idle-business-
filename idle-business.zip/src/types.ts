export interface Business {
  id: number;
  n: string; // Name
  lvl: number;
  cost: number; // Base cost
  inc: number; // Base income
  dur: number; // Duration in ms
  mgr: boolean; // Managed
  mc: number; // Manager cost
  prog: number; // Current progress percentage (0 - 100)
  run: boolean; // Active state
}

export interface Investment {
  id: number;
  n: string; // Name
  p: number; // Current Price
  basePrice: number; // For rendering sparklines/trends
  history: number[]; // Trend history for sparklines
  o: number; // Owned count
  rent?: number; // Rent per second for property type
  type: 'crypto' | 'stock' | 'prop';
}

export interface Achievement {
  id: number;
  n: string; // Title
  d: string; // Description
  goal: number;
  type: 'earnings' | 'prop' | 'prestige';
  done: boolean;
}

export interface Rival {
  n: string; // Name
  w: number; // Wealth
}

export interface Club {
  active: boolean;
  name: string;
  lvl: number;
  exp: number;
  req: number;
}

export interface GameState {
  cash: number;
  totalEarned: number;
  multiplier: number;
  club: Club;
  biz: Business[];
  inv: Investment[];
  ach: Achievement[];
  rivals: Rival[];
  lastTick: number;
}
