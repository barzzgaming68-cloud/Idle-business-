import React from 'react';
import { motion } from 'motion/react';
import { Bitcoin, TrendingUp, TrendingDown, Building2, Landmark, HelpCircle, ArrowUpRight, ArrowDownRight, Gem } from 'lucide-react';
import { Investment } from '../types';

interface InvestmentTabProps {
  inv: Investment[];
  cash: number;
  onTrade: (id: number, buy: boolean) => void;
}

export default function InvestmentTab({ inv, cash, onTrade }: InvestmentTabProps) {
  const formatCurrency = (val: number) => {
    return val.toLocaleString('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 });
  };

  // Helper to generate coordinates for a clean SVG sparkline
  const generateSparklinePoints = (history: number[]): string => {
    if (!history || history.length < 2) return "";
    const min = Math.min(...history);
    const max = Math.max(...history);
    const range = max - min === 0 ? 1 : max - min;
    const width = 120;
    const height = 40;
    const pointsCount = history.length;

    return history.map((val, idx) => {
      const x = (idx / (pointsCount - 1)) * width;
      // Invert y because SVG y goes downwards
      const y = height - 5 - ((val - min) / range) * (height - 10);
      return `${x},${y}`;
    }).join(' ');
  };

  // Calculate total passive income from properties (Apartemen)
  const totalPassiveRent = inv
    .filter(i => i.type === 'prop')
    .reduce((sum, item) => sum + ((item.rent || 0) * item.o), 0);

  return (
    <div className="space-y-4 font-sans">
      {/* Portfolio overview card */}
      <div className="custom-card rounded-xl p-5 relative overflow-hidden bg-[#111111] border border-white/10 shadow-lg">
        <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none">
          <Landmark className="w-24 h-24 text-brand-gold" />
        </div>
        <div className="text-xs uppercase tracking-[0.2em] text-brand-gold font-semibold mb-1 flex items-center gap-1.5 font-display">
          <Gem className="w-3.5 h-3.5" />
          Rangkuman Investasi Elit
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-3">
          <div>
            <span className="text-[10px] uppercase text-[#888888] tracking-widest font-semibold block">HASIL SEWA PASIF</span>
            <div className="text-xl sm:text-2xl font-mono font-semibold text-brand-gold">
              +{formatCurrency(totalPassiveRent)}
              <span className="text-xs font-sans text-[#888888] font-normal"> / detik</span>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {inv.map(item => (
              <div key={item.id} className="bg-black/40 px-2.5 py-1.5 rounded-lg border border-white/5 flex items-center gap-1.5">
                <span className="font-sans text-xs text-[#888888] font-medium">{item.n}:</span>
                <span className="font-mono text-xs font-bold text-white">{item.o} unit</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Market Items */}
      <div className="grid gap-4">
        {inv.map((item) => {
          const isAffordable = cash >= item.p;
          const isOwned = item.o > 0;

          // Compute price changes
          let priceChangePercent = 0;
          if (item.history && item.history.length >= 2) {
            const previous = item.history[item.history.length - 2];
            priceChangePercent = ((item.p - previous) / previous) * 100;
          }
          const isGoingUp = priceChangePercent >= 0;

          // Theme setups
          let themeColor = "border-brand-gold/15";
          let iconWrapperClass = "bg-brand-gold/10 text-brand-gold border-brand-gold/25";
          let itemIcon = <Bitcoin className="w-5 h-5 text-brand-gold" />;

          if (item.type === 'stock') {
            themeColor = "border-brand-gold/15";
            iconWrapperClass = "bg-brand-gold/10 text-brand-gold border border-brand-gold/25";
            itemIcon = <TrendingUp className="w-5 h-5 text-brand-gold" />;
          } else if (item.type === 'prop') {
            themeColor = "border-brand-gold/15";
            iconWrapperClass = "bg-brand-gold/10 text-brand-gold border border-brand-gold/25";
            itemIcon = <Building2 className="w-5 h-5 text-brand-gold" />;
          }

          return (
            <div
              key={item.id}
              className="custom-card rounded-xl p-5 relative overflow-hidden"
            >
              {/* Card Title & Held Stats */}
              <div className="flex items-center justify-between gap-4 mb-3">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center border ${iconWrapperClass}`}>
                    {itemIcon}
                  </div>
                  <div>
                    <h3 className="font-display font-medium text-sm sm:text-base text-slate-100 flex items-center gap-2">
                      {item.n}
                      {item.o > 0 && (
                        <span className="text-[10px] font-mono font-semibold bg-black border border-white/10 px-2 py-0.5 rounded text-brand-gold">
                          Milik: {item.o}
                        </span>
                      )}
                    </h3>
                    <p className="text-[10px] text-[#888888] uppercase tracking-[0.2em] font-semibold flex items-center gap-1 mt-0.5 font-sans">
                      {item.type === 'crypto' && 'High-volatility Crypto Asset'}
                      {item.type === 'stock' && 'Corporate Equity Asset'}
                      {item.type === 'prop' && 'Real Estate Passive Yield'}
                    </p>
                  </div>
                </div>

                {/* Real-time chart visualization for Stock & Crypto */}
                {item.type !== 'prop' && item.history && item.history.length > 1 && (
                  <div className="hidden sm:block">
                    <svg className="w-28 h-10 overflow-visible" viewBox="0 0 120 40">
                      <polyline
                        fill="none"
                        stroke={isGoingUp ? "#D4AF37" : "#e94560"}
                        strokeWidth="1.8"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        points={generateSparklinePoints(item.history)}
                      />
                    </svg>
                  </div>
                )}
              </div>

              {/* Price Details row */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-black/40 p-3 rounded-lg border border-white/5">
                <div>
                  <span className="text-[9px] text-[#888888] uppercase tracking-wider font-semibold block mb-0.5">HARGA PASAR SEKARANG</span>
                  <div className="flex items-baseline gap-1.5">
                    <span className="font-mono text-lg sm:text-xl font-bold text-slate-100">
                      {formatCurrency(item.p)}
                    </span>

                    {/* Change indicator pill */}
                    {item.type !== 'prop' ? (
                      <span className={`inline-flex items-center gap-0.5 font-mono text-[11px] font-semibold px-2 py-0.5 rounded-md ${
                        isGoingUp 
                          ? 'bg-emerald-500/10 text-emerald-400' 
                          : 'bg-rose-500/10 text-rose-400'
                      }`}>
                        {isGoingUp ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                        {isGoingUp ? '+' : ''}{priceChangePercent.toFixed(2)}%
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-0.5 font-mono text-[11px] font-semibold px-2 py-0.5 rounded-md bg-brand-gold/10 text-brand-gold border border-brand-gold/15">
                        +{formatCurrency(item.rent || 0)}/detik
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {/* Buy Button */}
                  <button
                    type="button"
                    onClick={() => onTrade(item.id, true)}
                    disabled={!isAffordable}
                    className={`px-4 py-2 rounded-lg font-sans font-semibold text-xs transition-all flex items-center justify-center gap-1 ${
                      isAffordable
                        ? 'bg-white hover:bg-neutral-100 text-black shadow-lg cursor-pointer active:scale-98'
                        : 'bg-zinc-900/40 text-zinc-550 border border-white/5 cursor-not-allowed font-medium'
                    }`}
                  >
                    Beli Asset
                  </button>

                  {/* Sell Button (Hidden/disabled for properties) */}
                  {item.type !== 'prop' ? (
                    <button
                      type="button"
                      onClick={() => onTrade(item.id, false)}
                      disabled={!isOwned}
                      className={`px-4 py-2 rounded-lg font-sans font-semibold text-xs border transition-all ${
                        isOwned
                          ? 'bg-[#181012] hover:bg-[#251317] border-rose-950 text-rose-400 cursor-pointer active:scale-98 font-bold'
                          : 'bg-zinc-900/30 border-white/5 text-zinc-550 cursor-not-allowed font-medium'
                      }`}
                    >
                      Jual Asset
                    </button>
                  ) : (
                    <div className="text-[10px] text-[#888888] font-medium max-w-[200px] text-right font-sans">
                      Unit real estat disewa secara berulang untuk seumur hidup.
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
