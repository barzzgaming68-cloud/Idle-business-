import React from 'react';
import { motion } from 'motion/react';
import { Trophy, Lock, Award, Sparkles, Building2, Banknote } from 'lucide-react';
import { Achievement, Investment } from '../types';

interface AchievementsTabProps {
  ach: Achievement[];
  totalEarned: number;
  inv: Investment[];
}

export default function AchievementsTab({ ach, totalEarned, inv }: AchievementsTabProps) {
  const formatCurrency = (val: number) => {
    return val.toLocaleString('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 });
  };

  // Helper to calculate progress values
  const getAchievementProgress = (a: Achievement) => {
    if (a.id === 0) {
      return {
        current: totalEarned,
        target: a.goal,
        percent: Math.min(100, (totalEarned / a.goal) * 100),
        readable: `${formatCurrency(totalEarned)} / ${formatCurrency(a.goal)}`
      };
    } else if (a.id === 1) {
      const aptCount = inv.find(i => i.id === 2)?.o || 0;
      return {
        current: aptCount,
        target: a.goal,
        percent: Math.min(100, (aptCount / a.goal) * 100),
        readable: `${aptCount} / ${a.goal} Apartemen`
      };
    } else if (a.id === 2) {
      return {
        current: totalEarned,
        target: a.goal,
        percent: Math.min(100, (totalEarned / a.goal) * 100),
        readable: `${formatCurrency(totalEarned)} / ${formatCurrency(a.goal)}`
      };
    }
    return { current: 0, target: 100, percent: 0, readable: "0 / 100" };
  };

  return (
    <div className="space-y-4 font-sans">
      {/* Stat header */}
      <div className="custom-card rounded-xl p-4 bg-[#111111] border border-white/10 flex justify-between items-center shadow-md">
        <span className="text-xs text-[#888888] font-medium uppercase tracking-wider">Total Penghargaan Terbuka</span>
        <span className="font-mono text-xs font-bold text-brand-gold bg-brand-gold/10 px-3 py-1 rounded-full border border-brand-gold/25 flex items-center gap-1.5">
          <Trophy className="w-3.5 h-3.5" />
          {ach.filter(a => a.done).length} / {ach.length} PIALA ELIT
        </span>
      </div>

      {/* Achievement list */}
      <div className="grid gap-3">
        {ach.map((a) => {
          const progress = getAchievementProgress(a);
          const isDone = a.done;

          // Beautiful color classes
          const borderClass = isDone ? "border-brand-gold/25 bg-[#161411]" : "border-white/5 bg-[#0e0e0e]/40";
          const iconWrapper = isDone 
            ? "bg-brand-gold/10 border-brand-gold/25 text-brand-gold" 
            : "bg-[#0c0c0c] border-white/5 text-zinc-600";

          return (
            <motion.div
              layoutId={`ach-card-${a.id}`}
              key={a.id}
              className={`custom-card rounded-xl p-5 ${borderClass} flex flex-col md:flex-row md:items-center justify-between gap-4 transition-all duration-300`}
            >
              <div className="flex items-start gap-3.5">
                {/* Trophy/Lock Icon Holder */}
                <div className={`w-11 h-11 rounded-lg flex items-center justify-center border shrink-0 relative ${iconWrapper}`}>
                  {isDone ? (
                    <>
                      <Trophy className="w-5 h-5 stroke-[1.8]" />
                      <Sparkles className="w-4 h-4 text-[#fcd34d] absolute -top-1 -right-1 animate-pulse" />
                    </>
                  ) : (
                    <Lock className="w-4 h-4 stroke-[2] opacity-60" />
                  )}
                </div>

                <div className="space-y-0.5">
                  <h3 className="font-sans font-semibold text-sm sm:text-base text-slate-100 flex items-center gap-2">
                    {a.n}
                    {isDone && (
                      <span className="text-[9px] uppercase font-bold tracking-[0.2em] text-brand-gold font-sans">
                        TERBUKA
                      </span>
                    )}
                  </h3>
                  <p className="text-xs text-[#888888] leading-normal font-sans">
                    {a.d}
                  </p>
                </div>
              </div>

              {/* Progress track */}
              <div className="w-full md:w-48 xl:w-56 shrink-0 space-y-1 bg-black/40 p-2.5 rounded-lg border border-white/5 leading-none">
                <div className="flex justify-between items-center text-[10px] font-mono mb-1">
                  <span className="text-zinc-500 uppercase tracking-wider text-[8px]">Progres</span>
                  <span className={isDone ? 'text-brand-gold font-bold' : 'text-zinc-400'}>
                    {progress.readable}
                  </span>
                </div>
                <div className="bg-black/60 h-2.5 rounded-full overflow-hidden p-0.5 border border-white/5">
                  <div 
                    className={`h-full rounded-full transition-all duration-300 ${
                      isDone ? 'bg-gradient-to-r from-brand-gold to-yellow-500' : 'bg-zinc-800'
                    }`}
                    style={{ width: `${progress.percent}%` }}
                  />
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
