import React from 'react';
import { motion } from 'motion/react';
import { Award, DollarSign, Coins, Building2, TrendingUp, Sparkles, Trophy } from 'lucide-react';
import { Rival, Investment } from '../types';

interface RankTabProps {
  rivals: Rival[];
  cash: number;
  inv: Investment[];
  playerName: string;
}

export default function RankTab({ rivals, cash, inv, playerName }: RankTabProps) {
  const formatCurrency = (val: number) => {
    return val.toLocaleString('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 });
  };

  // Calculate player's individual asset valuations
  const cryptoWealth = inv.filter(i => i.type === 'crypto').reduce((s, x) => s + (x.p * x.o), 0);
  const stockWealth = inv.filter(i => i.type === 'stock').reduce((s, x) => s + (x.p * x.o), 0);
  const propertyWealth = inv.filter(i => i.type === 'prop').reduce((s, x) => s + (x.p * x.o), 0);
  const myNetWorth = cash + cryptoWealth + stockWealth + propertyWealth;

  // Combine player with rivals, then sort by wealth DESC
  const allRank = [
    ...rivals,
    { n: playerName || "Player Anda", w: myNetWorth, isMe: true }
  ].sort((a, b) => b.w - a.w);

  // Find player's current position (1-indexed)
  const myIndex = allRank.findIndex(r => (r as any).isMe) + 1;

  return (
    <div className="space-y-4 font-sans">
      {/* Portfolio decomposition & stats breakdown */}
      <div className="custom-card rounded-xl p-5 bg-[#111111] border border-white/10 shadow-lg" id="breakdown-capital">
        <h3 className="text-xs font-display font-medium uppercase text-slate-200 tracking-[0.2em] mb-3 flex items-center gap-1.5">
          <TrendingUp className="w-3.5 h-3.5 text-brand-gold" />
          Laporan Alokasi Kekayaan Bersih Anda
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-black/40 p-3 rounded-lg border border-white/5">
          <div>
            <span className="text-[10px] uppercase text-brand-gold tracking-wider flex items-center gap-0.5 font-semibold">
              <DollarSign className="w-2.5 h-2.5 shrink-0 text-brand-gold" />
              Tunai & Likuid
            </span>
            <span className="font-mono text-sm font-semibold text-slate-100 block truncate">
              {formatCurrency(cash)}
            </span>
          </div>
          <div>
            <span className="text-[10px] uppercase text-brand-gold tracking-wider flex items-center gap-0.5 font-semibold">
              <Coins className="w-2.5 h-2.5 shrink-0 text-brand-gold" />
              Mata Kripto
            </span>
            <span className="font-mono text-sm font-semibold text-slate-100 block truncate">
              {formatCurrency(cryptoWealth)}
            </span>
          </div>
          <div>
            <span className="text-[10px] uppercase text-brand-gold tracking-wider flex items-center gap-0.5 font-semibold">
              <TrendingUp className="w-2.5 h-2.5 shrink-0 text-brand-gold" />
              Aset Saham
            </span>
            <span className="font-mono text-sm font-semibold text-slate-100 block truncate">
              {formatCurrency(stockWealth)}
            </span>
          </div>
          <div>
            <span className="text-[10px] uppercase text-brand-gold tracking-wider flex items-center gap-0.5 font-semibold">
              <Building2 className="w-2.5 h-2.5 shrink-0 text-brand-gold" />
              Aset Properti
            </span>
            <span className="font-mono text-sm font-semibold text-slate-100 block truncate">
              {formatCurrency(propertyWealth)}
            </span>
          </div>
        </div>
      </div>

      {/* Board & Table lists */}
      <div className="custom-card rounded-xl overflow-hidden bg-[#111111] border border-white/10 shadow-lg" id="global-board">
        <div className="p-4 bg-black/30 border-b border-white/10 flex justify-between items-center">
          <span className="text-xs font-display font-semibold text-slate-200">
            Papan Peringkat Global Konglomerasi
          </span>
          <span className="inline-flex items-center gap-1 font-mono text-[10px] font-bold text-brand-gold bg-brand-gold/15 px-2.5 py-0.5 rounded-full border border-brand-gold/25">
            Peringkat #{myIndex}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="border-b border-white/5 text-[9px] uppercase tracking-[0.2em] text-[#888888] font-bold bg-[#0d0d0d] text-left">
                <th className="py-3 px-4 w-12">No</th>
                <th className="py-3 px-4">Nama Elit</th>
                <th className="py-3 px-4 text-right">Kekayaan Bersih</th>
              </tr>
            </thead>
            <tbody>
              {allRank.map((r, i) => {
                const isMe = (r as any).isMe;
                const index = i + 1;

                // Color decorations for high ranks (1, 2, 3)
                let medal: any = null;
                if (index === 1) medal = <Trophy className="w-3.5 h-3.5 text-brand-gold shrink-0 inline" />;
                else if (index === 2) medal = <Trophy className="w-3.5 h-3.5 text-zinc-300 shrink-0 inline" />;
                else if (index === 3) medal = <Trophy className="w-3.5 h-3.5 text-[#a75d00] shrink-0 inline" />;

                return (
                  <tr
                    key={i}
                    className={`border-b border-white/5 transition-colors ${
                      isMe 
                        ? 'bg-brand-gold/10 hover:bg-brand-gold/15 font-semibold text-brand-gold' 
                        : 'hover:bg-white/5 text-zinc-300'
                    }`}
                  >
                    <td className="py-3.5 px-4 font-mono text-xs">
                      {medal ? (
                        <span className="flex items-center gap-1">
                          {medal}
                          <span className="sr-only">{index}</span>
                        </span>
                      ) : (
                        index
                      )}
                    </td>
                    <td className="py-3.5 px-4 font-sans text-xs sm:text-sm flex items-center gap-1.5">
                      {r.n}
                      {isMe && (
                        <span className="inline-flex items-center gap-0.5 text-[8px] uppercase font-bold tracking-widest bg-brand-gold/20 border border-brand-gold/30 px-2 py-0.5 rounded text-brand-gold">
                          Anda
                        </span>
                      )}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono text-xs sm:text-sm">
                      {formatCurrency(r.w)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
