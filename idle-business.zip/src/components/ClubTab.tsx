import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Users, ShieldCheck, Flame, Plus, Sparkles, Building, Briefcase, Award } from 'lucide-react';
import { Club } from '../types';

interface ClubTabProps {
  club: Club;
  cash: number;
  onCreateClub: (name: string) => void;
  onDonateClub: (cashAmount: number, xpAmount: number) => void;
}

export default function ClubTab({ club, cash, onCreateClub, onDonateClub }: ClubTabProps) {
  const [nameIn, setNameIn] = useState("");

  const formatCurrency = (val: number) => {
    return val.toLocaleString('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 });
  };

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (nameIn.trim() && cash >= 10000) {
      onCreateClub(nameIn.trim());
    }
  };

  // Club donation tiers
  const donationTiers = [
    {
      id: 0,
      title: "Gala Sosial Elit",
      desc: "Sponsori pertemuan makan malam sosial para eksekutif papan atas untuk membangun relasi relik.",
      cost: 5000,
      xp: 500,
      icon: <Flame className="w-5 h-5 text-brand-gold" />
    },
    {
      id: 1,
      title: "Investasi Modal Ventura",
      desc: "Sediakan pendanaan tahap awal bagi startup potensial demi pengaruh korporat klub.",
      cost: 50000,
      xp: 6000,
      icon: <Briefcase className="w-5 h-5 text-brand-gold" />
    },
    {
      id: 2,
      title: "Merger Konglomerasi",
      desc: "Gabungkan anak perusahaan besar untuk memaksimalkan cengkraman finansial global klub.",
      cost: 250000,
      xp: 40000,
      icon: <Building className="w-5 h-5 text-brand-gold" />
    }
  ];

  return (
    <div className="space-y-4 font-sans">
      {!club.active ? (
        /* Club Creation UI */
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="custom-card rounded-2xl p-6 text-center max-w-md mx-auto space-y-6"
        >
          <div className="relative mx-auto w-16 h-16 rounded-2xl bg-[#111] border border-brand-gold/40 flex items-center justify-center shadow-lg">
            <Users className="w-8 h-8 text-brand-gold stroke-[2]" />
            <Sparkles className="w-5 h-5 text-brand-gold absolute -top-1 -right-1 animate-pulse" />
          </div>

          <div className="space-y-2">
            <h2 className="font-serif italic font-medium text-xl text-slate-100">
              Piagam Syarikat Klub
            </h2>
            <p className="text-xs text-[#888888] leading-relaxed max-w-xs mx-auto">
              Bentuk perkumpulan konglomerat eksklusif Anda sendiri untuk menguasai pasar global dan membuka multiplier bonus permanen.
            </p>
          </div>

          <form onSubmit={handleCreate} className="space-y-4 text-left">
            <div>
              <label htmlFor="clubName" className="block text-[10px] uppercase tracking-widest text-[#888888] font-bold mb-1.5 ">
                Nama Klub Syarikat
              </label>
              <input
                id="clubName"
                type="text"
                maxLength={30}
                placeholder="cth: Nusantara Holdings, Jayakarta Club..."
                value={nameIn}
                onChange={(e) => setNameIn(e.target.value)}
                className="w-full bg-[#0c0c0c] border border-white/10 rounded-lg p-2.5 px-3.5 text-sm outline-none text-slate-200 placeholder-zinc-700 focus:border-brand-gold/60 transition-colors"
                required
              />
            </div>

            <button
              type="submit"
              disabled={cash < 10000 || !nameIn.trim()}
              className={`w-full py-3 rounded-lg font-sans font-bold text-xs select-none transition-all flex items-center justify-center gap-1.5 uppercase tracking-wider ${
                cash >= 10000 && nameIn.trim()
                  ? 'bg-white hover:bg-neutral-100 text-black shadow-xl cursor-pointer active:scale-98'
                  : 'bg-zinc-900/60 text-zinc-550 border border-white/5 cursor-not-allowed'
              }`}
            >
              Dirikan Klub & Piagam ({formatCurrency(10000)})
            </button>
          </form>
        </motion.div>
      ) : (
        /* Club Dashboard UI */
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="space-y-5"
        >
          {/* Main info header */}
          <div className="custom-card rounded-2xl p-6 border-l-4 border-l-brand-gold/80 bg-[#111111] relative overflow-hidden border border-white/10 shadow-lg">
            <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none">
              <Users className="w-32 h-32 text-brand-gold" />
            </div>

            <div className="flex items-start justify-between gap-4">
              <div>
                <span className="text-[9px] uppercase tracking-[0.2em] text-[#888888] font-bold block mb-1">
                  KLUB ELITE AKTIF
                </span>
                <h2 className="font-serif italic font-medium text-xl sm:text-2xl text-slate-100 flex items-center gap-2">
                  {club.name}
                  <span className="text-xs font-mono font-bold text-brand-gold bg-brand-gold/10 border border-brand-gold/20 px-2 py-0.5 rounded-full flex items-center gap-0.5">
                    <Award className="w-3.5 h-3.5" />
                    Level {club.lvl}
                  </span>
                </h2>
              </div>
              <span className="font-mono text-xs text-brand-gold font-semibold bg-brand-gold/10 border border-brand-gold/20 px-2.5 py-1 rounded-lg">
                Multiplier: +{((club.lvl - 1) * 15).toFixed(0)}% Profit
              </span>
            </div>

            {/* Experience Meter */}
            <div className="mt-5 space-y-1.5">
              <div className="flex justify-between items-center text-xs font-mono">
                <span className="text-[#888888] uppercase tracking-wider text-[9px]">Pamor Eksekutif</span>
                <span className="text-brand-gold font-semibold">{club.exp} / {club.req} EXP</span>
              </div>
              <div className="bg-black/60 h-3 rounded-full overflow-hidden border border-white/5 p-0.5">
                <div 
                  className="h-full rounded-full bg-gradient-to-r from-brand-gold to-yellow-500 transition-all duration-300"
                  style={{ width: `${Math.min(100, (club.exp / club.req) * 100)}%` }}
                />
              </div>
              <p className="text-[10px] text-[#888888] italic font-sans">
                Tingkatkan pamor klub Anda untuk memperluas jangkauan investasi dan multiplier usaha global.
              </p>
            </div>
          </div>

          {/* Prestige Donation section */}
          <div>
            <h3 className="font-display font-medium text-sm sm:text-base text-slate-200 mb-3 flex items-center gap-1.5 uppercase tracking-wider">
              <ShieldCheck className="w-4 h-4 text-brand-gold" />
              Sponsori Kegiatan Syarikat
            </h3>
            <div className="grid gap-3">
              {donationTiers.map((tier) => {
                const isAffordable = cash >= tier.cost;
                return (
                  <div
                    key={tier.id}
                    className="custom-card rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                  >
                    <div className="flex items-start gap-3 max-w-sm">
                      <div className="w-9 h-9 rounded-lg bg-black border border-white/10 flex items-center justify-center shrink-0">
                        {tier.icon}
                      </div>
                      <div>
                        <h4 className="font-sans font-semibold text-[#f8fafc] text-sm">
                          {tier.title}
                        </h4>
                        <p className="text-[11px] text-[#888888] leading-normal mt-0.5 font-sans">
                          {tier.desc}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center justify-between sm:justify-start gap-4 border-t border-white/5 sm:border-0 pt-3 sm:pt-0 shrink-0">
                      <div className="text-left sm:text-right font-mono">
                        <span className="text-[9px] uppercase tracking-wider text-brand-gold block font-semibold">+ {tier.xp} Club EXP</span>
                        <span className="font-bold text-xs text-white">Biaya: {formatCurrency(tier.cost)}</span>
                      </div>

                      <button
                        type="button"
                        onClick={() => onDonateClub(tier.cost, tier.xp)}
                        disabled={!isAffordable}
                        className={`px-4 py-2 rounded-lg font-sans font-semibold text-xs transition-all ${
                          isAffordable
                            ? 'bg-white hover:bg-neutral-100 text-black cursor-pointer active:scale-98 shadow-md font-bold'
                            : 'bg-zinc-900/60 text-zinc-550 border border-white/5 cursor-not-allowed font-semibold'
                        }`}
                      >
                        Donasi
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
}
