import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Coffee, Wrench, Factory, UserCheck, ArrowUpCircle, Play, Sliders, Target } from 'lucide-react';
import { Business } from '../types';

interface BusinessTabProps {
  biz: Business[];
  cash: number;
  multiplier: number;
  onUpgrade: (id: number) => void;
  onHireManager: (id: number) => void;
  onManualTrigger: (id: number) => void;
}

// Map IDs to specific icons and visual colors
const BIZ_METADATA: Record<number, { icon: React.ReactNode; color: string; bg: string; border: string; accent: string; desc: string }> = {
  0: { 
    icon: <Coffee className="w-5 h-5 text-brand-gold" />, 
    color: "from-brand-gold to-[#9a781b]",
    bg: "#111111",
    border: "border-brand-gold/15",
    accent: "text-brand-gold",
    desc: "Menyajikan arabika kualitas premium untuk para eksekutif perkotaan." 
  },
  1: { 
    icon: <Wrench className="w-5 h-5 text-brand-gold" />, 
    color: "from-brand-gold to-[#9a781b]",
    bg: "#111111",
    border: "border-brand-gold/15",
    accent: "text-brand-gold",
    desc: "Bengkel modern berteknologi tinggi untuk supercar elite kota." 
  },
  2: { 
    icon: <Factory className="w-5 h-5 text-brand-gold" />, 
    color: "from-brand-gold to-[#9a781b]",
    bg: "#111111",
    border: "border-brand-gold/15",
    accent: "text-brand-gold",
    desc: "Memproduksi setelan jas dan pakaian haute couture eksklusif." 
  }
};

export default function BusinessTab({
  biz,
  cash,
  multiplier,
  onUpgrade,
  onHireManager,
  onManualTrigger
}: BusinessTabProps) {

  const formatCurrency = (val: number) => {
    return val.toLocaleString('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 });
  };

  const calculateUpgradeCost = (b: Business) => {
    return b.cost * Math.pow(1.15, b.lvl);
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center bg-[#111111] p-3.5 rounded-xl border border-white/10 shadow-sm">
        <span className="text-xs text-zinc-400 flex items-center gap-1">
          <Target className="w-3.5 h-3.5 text-brand-gold" />
          Unit Usaha Riil Indonesia
        </span>
        <span className="text-xs font-mono text-brand-gold font-semibold bg-brand-gold/10 px-2.5 py-0.5 rounded-full border border-brand-gold/20">
          Uang Masuk x{(multiplier).toFixed(2)}
        </span>
      </div>

      <div className="grid gap-4">
        {biz.map((b) => {
          const meta = BIZ_METADATA[b.id] || {
            icon: <Sliders className="w-5 h-5 text-brand-gold" />,
            color: "from-brand-gold to-[#9a781b]",
            bg: "#111111",
            border: "border-brand-gold/15",
            accent: "text-brand-gold",
            desc: "Usaha potensial masa depan."
          };

          const upCost = calculateUpgradeCost(b);
          const currentIncome = b.inc * b.lvl * multiplier;
          const progressPercent = b.lvl > 0 ? b.prog : 0;
          const isAffordable = cash >= upCost;
          const isManagerAffordable = cash >= b.mc && b.lvl > 0 && !b.mgr;

          return (
            <motion.div
              key={b.id}
              layoutId={`biz-card-${b.id}`}
              className="custom-card rounded-xl p-5 relative overflow-hidden flex flex-col justify-between"
              style={{ background: meta.bg }}
            >
              {/* Card top banner with details */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-black border border-white/10 flex items-center justify-center">
                    {meta.icon}
                  </div>
                  <div>
                    <h3 className="font-display font-medium text-sm sm:text-base text-slate-100 flex items-center gap-1.5">
                      {b.n}
                      {b.lvl > 0 ? (
                        <span className="font-mono text-xs text-brand-gold bg-brand-gold/15 px-2 py-0.5 rounded font-semibold border border-brand-gold/25">
                          Lv.{b.lvl}
                        </span>
                      ) : (
                        <span className="font-sans text-[9px] uppercase font-bold tracking-widest text-[#888888] bg-[#1a1a1a] px-2 py-0.5 rounded border border-white/5">
                          Terkunci
                        </span>
                      )}
                    </h3>
                    <p className="text-[11px] text-[#888888] leading-tight max-w-[280px] sm:max-w-sm font-sans mt-0.5">
                      {meta.desc}
                    </p>
                  </div>
                </div>

                <div className="text-left sm:text-right">
                  <span className="text-[9px] text-[#888888] uppercase tracking-[0.2em] font-semibold block mb-0.5">HASIL</span>
                  <span className={`font-mono text-base font-semibold ${meta.accent}`}>
                    {b.lvl > 0 ? `+${formatCurrency(currentIncome)}` : "$0"}
                  </span>
                </div>
              </div>

              {/* Progress bar area - Clickable to start business process */}
              <div 
                onClick={() => {
                  if (!b.run && b.lvl > 0) {
                    onManualTrigger(b.id);
                  }
                }}
                className={`relative w-full h-10 rounded-lg border overflow-hidden select-none cursor-pointer flex items-center justify-center transition-all ${
                  b.lvl > 0
                    ? 'border-white/5 bg-zinc-950/80 hover:bg-black hover:border-brand-gold/30'
                    : 'border-white/5 bg-[#0c0c0c] text-zinc-650 cursor-not-allowed'
                }`}
              >
                {/* Visual fill indicator */}
                {b.lvl > 0 && (
                  <div 
                    className={`absolute top-0 left-0 bottom-0 bg-gradient-to-r ${meta.color} transition-all duration-75 opacity-90`}
                    style={{ width: `${progressPercent}%` }}
                  />
                )}

                <span className="relative z-10 font-sans font-medium text-xs text-slate-100 tracking-wide flex items-center gap-1.5">
                  {b.lvl === 0 ? (
                    <span className="text-zinc-550 uppercase tracking-wider text-[9px] font-bold">Beli Unit Usaha ini untuk Mulai</span>
                  ) : b.mgr ? (
                    <span className="flex items-center gap-1 font-mono text-emerald-400 text-xs">
                      <UserCheck className="w-3.5 h-3.5 animate-pulse" />
                      OTOMATIS (Ada Manager)
                    </span>
                  ) : b.run ? (
                    <span className="flex items-center gap-1 block text-zinc-100 font-medium">
                      Memproses... {(100 - b.prog).toFixed(0)}% tersisa
                    </span>
                  ) : (
                    <span className="flex items-center gap-1.5 text-brand-gold font-semibold uppercase tracking-wider text-[10px]">
                      <Play className="w-2.5 h-2.5 text-brand-gold fill-brand-gold" />
                      Mulai Operasional Manual
                    </span>
                  )}
                </span>
              </div>

              {/* Action Buttons: Upgrade Level & Hire Manager */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-4">
                {/* Upgrade Button */}
                <button
                  type="button"
                  onClick={() => onUpgrade(b.id)}
                  disabled={!isAffordable}
                  className={`flex flex-col items-center justify-center p-2 rounded-lg font-sans transition-all leading-snug ${
                    isAffordable 
                      ? 'bg-white hover:bg-neutral-100 text-black shadow-lg cursor-pointer active:scale-98 font-bold' 
                      : 'bg-zinc-900/60 text-zinc-550 border border-white/5 cursor-not-allowed font-semibold'
                  }`}
                >
                  <span className="text-[9px] uppercase tracking-wider opacity-80 flex items-center gap-1 mb-0.5">
                    <ArrowUpCircle className="w-3.5 h-3.5" />
                    {b.lvl === 0 ? 'Beli Lisensi' : 'Upgrade Usaha'}
                  </span>
                  <span className="text-xs sm:text-sm font-semibold font-mono">
                    {formatCurrency(upCost)}
                  </span>
                </button>

                {/* Manager Button */}
                <button
                  type="button"
                  onClick={() => onHireManager(b.id)}
                  disabled={b.mgr || b.lvl === 0 || !isManagerAffordable}
                  className={`flex flex-col items-center justify-center p-2 rounded-lg font-sans transition-all leading-snug border ${
                    b.mgr
                      ? 'bg-zinc-950/40 border-emerald-900/40 text-emerald-500 cursor-default font-bold'
                      : isManagerAffordable && b.lvl > 0
                        ? 'bg-[#111111] hover:bg-black border-brand-gold/40 text-brand-gold cursor-pointer active:scale-98 font-bold'
                        : 'bg-zinc-900/30 border-white/5 text-zinc-550 cursor-not-allowed font-semibold'
                  }`}
                >
                  <span className="text-[9px] uppercase tracking-wider opacity-85 flex items-center gap-1 mb-0.5">
                    <UserCheck className="w-3.5 h-3.5" />
                    {b.mgr ? 'Manager Aktif' : 'Pekerjakan Manager'}
                  </span>
                  <span className="text-xs sm:text-sm font-semibold font-mono">
                    {b.mgr ? 'AUTO ACTIVE' : formatCurrency(b.mc)}
                  </span>
                </button>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
