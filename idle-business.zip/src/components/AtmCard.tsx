import React from 'react';
import { motion } from 'motion/react';
import { Cpu, Wifi, Shield } from 'lucide-react';

interface AtmCardProps {
  totalEarned: number;
  playerName: string;
}

export default function AtmCard({ totalEarned, playerName }: AtmCardProps) {
  // Determine card tier properties with Sophisticated Dark palette
  let tierName = "STANDARD DEBIT";
  let gradientClass = "from-[#111111] via-[#1a1a1a] to-[#0a0a0a] border border-white/5 text-zinc-300";
  let badgeColor = "bg-zinc-800/40 text-zinc-350 border border-zinc-700/30";
  let cardClass = "";

  if (totalEarned >= 1000000) {
    tierName = "ULTIMATE BLACK CARD";
    gradientClass = "from-[#0a0a0a] via-[#151515] to-[#010101] border border-brand-gold/60 text-brand-gold shadow-[0_0_20px_rgba(212,175,55,0.15)]";
    badgeColor = "bg-brand-gold/15 text-brand-gold border border-brand-gold/30";
    cardClass = "animate-pulse-glow";
  } else if (totalEarned >= 100000) {
    tierName = "GOLD DEBIT";
    gradientClass = "from-[#b39330] via-[#d4af37] to-[#8c6d1d] border border-[#f5d76d]/30 text-slate-950";
    badgeColor = "bg-slate-950/20 text-slate-950 border border-slate-950/10 font-bold";
  } else if (totalEarned >= 10000) {
    tierName = "SILVER DEBIT";
    gradientClass = "from-zinc-300 via-stone-200 to-zinc-400 border border-white/20 text-zinc-900";
    badgeColor = "bg-zinc-900/10 text-zinc-900 border border-zinc-950/15 font-semibold";
  }

  // Format credit card number style
  const formattedCardNumber = "4588  0012  " + 
    (totalEarned >= 100000 ? "8899" : "3344") + "  " + 
    (totalEarned >= 1000000 ? "9999" : "1102");

  return (
    <motion.div
      initial={{ scale: 0.95, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      className={`relative w-full max-w-sm h-52 mx-auto rounded-2xl p-6 overflow-hidden bg-gradient-to-br ${gradientClass} ${cardClass} shadow-3xl flex flex-col justify-between`}
    >
      {/* Decorative luxury watermark as in HTML specs */}
      <div className="absolute top-4 right-5 opacity-15 font-serif italic text-4xl tracking-tight select-none pointer-events-none">
        ELITE
      </div>

      {/* Decorative hologram overlay */}
      <div className="absolute inset-0 bg-radial-gradient from-transparent to-black/20 pointer-events-none mix-blend-overlay" />
      
      {/* Top row */}
      <div className="flex justify-between items-start relative z-10">
        <div className="flex items-center gap-3">
          <div className="p-1 px-2.5 rounded-md bg-white/5 backdrop-blur-md border border-white/10 flex items-center justify-center">
            <Cpu className="w-6 h-6 rotate-90 opacity-90 text-brand-gold" />
          </div>
          <Wifi className="w-5 h-5 rotate-90 opacity-70" />
        </div>
        <div className="flex items-center gap-1.5 bg-black/10 px-2 py-0.5 rounded-lg border border-white/5 backdrop-blur-sm">
          <Shield className="w-3.5 h-3.5 text-emerald-400" />
          <span className="font-mono text-[8px] tracking-widest uppercase opacity-75">SECURE</span>
        </div>
      </div>

      {/* Card number */}
      <div className="my-2 relative z-10">
        <div className="font-mono text-lg sm:text-xl tracking-[0.2em] font-medium drop-shadow-md">
          {formattedCardNumber}
        </div>
      </div>

      {/* Bottom row */}
      <div className="flex justify-between items-end relative z-10">
        <div>
          <div className="font-mono text-[8px] tracking-widest uppercase opacity-50 mb-0.5">
            Cardholder
          </div>
          <div className="font-sans font-bold text-xs uppercase tracking-wider truncate max-w-[170px]">
            {playerName || "ELIT MEMBER"}
          </div>
        </div>

        <div className="text-right flex flex-col items-end">
          <span className={`inline-block font-display font-semibold px-2 py-0.5 rounded text-[9px] uppercase tracking-wider ${badgeColor}`}>
            {tierName}
          </span>
          <div className="font-serif italic font-semibold text-xs tracking-widest opacity-80 mt-2">
            Syarikat Elit
          </div>
        </div>
      </div>
    </motion.div>
  );
}
