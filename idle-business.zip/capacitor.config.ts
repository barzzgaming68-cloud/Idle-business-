import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.syarikatelit.app',
  appName: 'Syarikat Elit',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  }
};

export default config;
